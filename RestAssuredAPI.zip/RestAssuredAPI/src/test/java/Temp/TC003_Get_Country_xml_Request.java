package Temp;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC003_Get_Country_xml_Request {
	
		@Test
		void getCountryRequest() {
			
			// Specify Base URI
			//RestAssured.baseURI="https://restcountries.eu";
			RestAssured.baseURI="https://ws.footballpool.dataaccess.eu";
			
			// Create Request Object
			RequestSpecification httpRequest = RestAssured.given();
			
			// Create Response Object
			Response response = httpRequest.request(Method.GET, "/info.wso");
			
			// Body of Response		
			String responseBody = response.getBody().asString();
			System.out.println("Response Body : ");
			System.out.println(responseBody);
			
			// Status Code Validation
			int statusCode = response.getStatusCode();
			System.out.println("Status Code : " +statusCode);
			Assert.assertEquals(statusCode, 200);
			
			// Status Line Validation
			String statusLine = response.getStatusLine();
			System.out.println("Status Line : " +statusLine);
			Assert.assertEquals(statusLine, "HTTP/1.1 200 OK");	
			
			// Body Contains some value Validation
			Assert.assertEquals(responseBody.contains("AllCardsInfo"), true);
			
			// All Header Validation
			Headers allheaders=response.headers();
			System.out.println();
			System.out.println("All Headers are as below...");
			
			for(Header header : allheaders)
			{
				System.out.println(header.getName() + "         " + header.getValue());
			}
		}
}
