package Temp;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC001_GET_Request {

	@Test
	void getWeatherRequest() {
		
		// Specify Base URI
		RestAssured.baseURI="https://demoqa.com/utilities/weather/city";
		
		// Handle Basic Authentication
		PreemptiveBasicAuthScheme authscheme = new PreemptiveBasicAuthScheme();
		authscheme.setUserName("ToolsQA");
		authscheme.setUserName("TestPassword");
		RestAssured.authentication = authscheme;
		
		// Create Request Object
		RequestSpecification httpRequest = RestAssured.given();
		
		// Create Response Object
		Response response = httpRequest.request(Method.GET, "/Hyderabad");
		
		// Body of Response		
		String responseBody = response.getBody().asString();
		System.out.println("Weather Response Body : ");
		System.out.println(responseBody);
		
		// Status Code Validation
		int statusCode = response.getStatusCode();
		System.out.println("Status Code : " +statusCode);
		Assert.assertEquals(statusCode, 200);
		
		// Status Line Validation
		String statusLine = response.getStatusLine();
		System.out.println("Status Line : " +statusLine);
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK");
		
		// Body Contains some value Validation
		Assert.assertEquals(responseBody.contains("Hyderabad"), true);
		
		// Header Validation
		String contentType=response.header("Content-Type");
		System.out.println("Header Content-Type : "+contentType);
		Assert.assertEquals(contentType, "application/json; charset=utf-8");
		
		// All Header Validation
		Headers allheaders=response.headers();
		System.out.println();
		System.out.println("All Headers are as below...");
		
		for(Header header : allheaders)
		{
			System.out.println(header.getName() + "         " + header.getValue());
		}
	
		// Validate JSON Response body
		
		JsonPath jsonpath = response.jsonPath();
		System.out.println();
		System.out.println(jsonpath.get("City"));
		System.out.println(jsonpath.get("Temperature"));
		System.out.println(jsonpath.get("Humidity"));
		
		Assert.assertEquals(jsonpath.get("City"), "Hyderabad");		
	}
}
