package Temp;

import org.json.simple.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC001_POST_Request {
	
	@Test
	void postRegistration() {
		
		// Specify Base URI
		RestAssured.baseURI="https://demoqa.com/customer";				
				
		// Create Request Object
		RequestSpecification httpRequest = RestAssured.given();
		
		// Create Response Object
		JSONObject requestParams = new JSONObject();
		requestParams.put("FirstName", "Jitendra");
		requestParams.put("LastName", "TOMAR");
		requestParams.put("UserName", "gtu12tomar");
		requestParams.put("FirstName", "Test123");
		requestParams.put("Email", "Jitendra.TOMAR@gmail.com");
		
		httpRequest.header("Content-Type", "application/json");
		httpRequest.body(requestParams.toJSONString());
		
		Response response = httpRequest.request(Method.POST, "/register");
				
		// Body of Response		
		String responseBody = response.getBody().asString();
		System.out.println("Weather Response Body : ");
		System.out.println(responseBody);
		
		// Status Code Validation
		int statusCode = response.getStatusCode();
		System.out.println("Status Code : " +statusCode);
		Assert.assertEquals(statusCode, 200);
		
		// Success Code Validation
		String successCode = response.jsonPath().get("SuccessCode");
		Assert.assertEquals(successCode, "OPERATION_SUCCESS");
		
		
	}

}
