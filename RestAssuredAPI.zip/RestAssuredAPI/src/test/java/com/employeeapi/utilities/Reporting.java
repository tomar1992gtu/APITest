package com.employeeapi.utilities;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class Reporting extends TestListenerAdapter{
	
	public static ExtentHtmlReporter htmlrepoter;
	public static ExtentReports extentreport;
	public static ExtentTest logger;	
	
	public void onStart(ITestContext testContext) {
		
		String timestamp=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String repName = "Test-Report" + timestamp + ".html";
		
		htmlrepoter=new ExtentHtmlReporter(System.getProperty("user.dir")+"/test-output/"+repName);
		htmlrepoter.loadConfig(System.getProperty("user.dir")+"/extent-config.xml");	
		
		extentreport=new ExtentReports();
		extentreport.attachReporter(htmlrepoter);
		
		htmlrepoter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlrepoter.config().setTheme(Theme.DARK);
	}
	
	public void onTestSuccess(ITestResult result) {
		logger=extentreport.createTest(result.getName());
		logger.log(Status.PASS, MarkupHelper.createLabel(result.getName(), ExtentColor.GREEN));
	}
	
	public void onTestFailure(ITestResult result) {
		logger=extentreport.createTest(result.getName());
		logger.log(Status.FAIL, MarkupHelper.createLabel(result.getName(), ExtentColor.RED));
		
		String screenshot = System.getProperty("user.dir")+"\\Screenshots\\"+result.getName()+".png";
		
		File f = new File(screenshot);
		if(f.exists())
		{
			try {
				logger.fail("Screenshot as below :"+ logger.addScreenCaptureFromPath(screenshot));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}	
	}
	
	public void onTestSkipped(ITestResult result) {
		logger=extentreport.createTest("SKIPPED : " +result.getName());
		logger.log(Status.SKIP, MarkupHelper.createLabel(result.getName(), ExtentColor.ORANGE));		
	}
	
	public void onFinish(ITestContext testContext) {
		extentreport.flush();		
	}

}
