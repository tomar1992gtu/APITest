package com.employeeapi.testCases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.employeeapi.base.BaseClass;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;

public class TC001_Get_All_Employees extends BaseClass{
	
	public static JsonPath jsonPathEvaluator;
		
	@BeforeClass
	void getAllEmployees() throws InterruptedException 
	{
		logger.info("********************* Started TC001_Get_All_Employees *********************");
		
		RestAssured.baseURI = "https://dummy.restapiexample.com/api/v1";
		httpRequest = RestAssured.given();
		response=httpRequest.request(Method.GET, "/employees");
		
		// First get the JsonPath object instance from the Response interface
		// This will be used to validate data in JSON body.
		jsonPathEvaluator = response.jsonPath();
		Thread.sleep(3000);
	}
	
	@Test
	void checkResponceBody() 
	{
		logger.info("********************* TC001 : M1 : CheckResponceBody *********************");
		String responseBody=response.getBody().asString();
		logger.info("Response Body ==> "+responseBody);
		Assert.assertTrue(responseBody!=null);
	}
	
	@Test
	void checkStatusCode() 
	{
		logger.info("********************* TC001 : M2 :CheckStatusCode *********************");
		int statusCode=response.getStatusCode();
		logger.info("Status Code ==> "+statusCode);
		Assert.assertEquals(statusCode, 200);
	}
	
	@Test
	void checkStatusLine() 
	{
		logger.info("********************* TC001 : M3 :CheckStatusLine *********************");
		String statusLine=response.getStatusLine();
		logger.info("Status Line ==> "+statusLine);
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK");
	}
	
	@Test
	void checkResponseTime() 
	{
		logger.info("********************* TC001 : M4: CheckResponseTime *********************");
		long responseTime=response.getTime();
		logger.info("Response Time ==> "+responseTime);
		
		if(responseTime>2000)
			logger.warn("Response Time is greater than 2000");
		Assert.assertTrue(responseTime<2000);
	}
	
	@Test
	void checkContentType() 
	{
		logger.info("********************* TC001 : M5: CheckContentType *********************");
		String contentType=response.header("Content-Type");
		logger.info("Content Type ==> "+contentType);
		Assert.assertEquals(contentType, "application/json");
	}
	
	@Test
	void checkServerType() 
	{
		logger.info("********************* TC001 : M6 :CheckServerType *********************");
		String serverType=response.header("Server");
		logger.info("Server Type ==> "+serverType);
		Assert.assertEquals(serverType, "cloudflare");
	}
	
	@Test
	void checkContentEncoding() 
	{
		logger.info("********************* TC001 : M7 :CheckContentEncoding *********************");
		String contentEncoding=response.header("Content-Encoding");
		logger.info("Content Encoding ==> "+contentEncoding);
		Assert.assertEquals(contentEncoding, "gzip");
	}
	
	@Test
	void checkContentLength() 
	{
		logger.info("********************* TC001 : M8 :CheckContentLength *********************");
		String contentLength=response.header("Content-Length");
		logger.info("Content Length ==> "+contentLength);
		
		if(Integer.parseInt(contentLength)<100)
			logger.warn("Content Length is less than 100");
		
		Assert.assertTrue(Integer.parseInt(contentLength)>100);
	}
	
	@Test
	void checkCookie() 
	{
		logger.info("********************* TC001 : M9 :CheckCookie *********************");
		String cookie=response.getCookie("PHPSESSID");
		logger.info("Cookie ==> "+cookie);
	}
	
	@Test
	void getMessage() 
	{
		logger.info("********************* TC001 : M10 : Final Message *********************");
		String message = jsonPathEvaluator.getString("message");
		logger.info("Message ==> "+message);
		Assert.assertEquals(message, "Successfully! All records has been fetched.");		
	}
	
	
	
	@AfterClass
	void tearDown()
	{
		logger.info("********************* Finished TC001_Get_All_Employees *********************");
	}

}
