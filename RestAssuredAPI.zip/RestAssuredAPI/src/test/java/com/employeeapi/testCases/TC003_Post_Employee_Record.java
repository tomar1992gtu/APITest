package com.employeeapi.testCases;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.employeeapi.base.BaseClass;
import com.employeeapi.utilities.RestUtils;

import io.restassured.RestAssured;
import io.restassured.http.Method;

public class TC003_Post_Employee_Record extends BaseClass{
	
	String empName = RestUtils.empName();
	String empSalary = RestUtils.empSal();
	String empAge = RestUtils.empAge();
	
	
	@BeforeClass
	void getEmployeeRecord() throws InterruptedException 
	{
		logger.info("********************* Started TC003_Post_Employee_Record *********************");
		
		RestAssured.baseURI = "https://dummy.restapiexample.com/api/v1";
		httpRequest = RestAssured.given();
		
		JSONObject requestParams = new JSONObject();
		requestParams.put("name", empName);
		requestParams.put("salary", empSalary);
		requestParams.put("name", empAge);
		
		httpRequest.header("Content-Type","application/json");
		httpRequest.body(requestParams.toJSONString());
		
		response=httpRequest.request(Method.POST, "/create");
		Thread.sleep(3000);
	}
	
	@Test
	void checkSuccessCode() 
	{
		logger.info("********************* TC003 : M1 : SuccessCode *********************");
		String successCode = response.jsonPath().get("SuccessCode");
		logger.info("Content Encoding ==> "+successCode);		
		Assert.assertEquals(successCode, "OPERATION_SUCCESS");

	}
	
	@AfterClass
	void tearDown()
	{
		logger.info("********************* Finished TC003_Post_Employee_Record *********************");
	}


}
