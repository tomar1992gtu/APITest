package com.employeeapi.testCases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.employeeapi.base.BaseClass;

import io.restassured.RestAssured;
import io.restassured.http.Method;

public class TC002_Get_Single_Employee_Record extends BaseClass{

	@BeforeClass
	void getEmployeeRecord() throws InterruptedException 
	{
		logger.info("********************* Started TC002_Get_Single_Employee_Record *********************");
		
		RestAssured.baseURI = "https://dummy.restapiexample.com/api/v1";
		httpRequest = RestAssured.given();
		response=httpRequest.request(Method.GET, "/employee/"+empID);
		Thread.sleep(3000);
	}
	
	@Test
	void checkResponceBody() 
	{
		logger.info("********************* TC002 : M1 : CheckResponceBody *********************");
		String responseBody=response.getBody().asString();
		logger.info("Response Body ==> "+responseBody);
		Assert.assertEquals(responseBody.contains(empID), true);
	}
	
	@Test
	void checkStatusCode() 
	{
		logger.info("********************* TC002 : M2 :CheckStatusCode *********************");
		int statusCode=response.getStatusCode();
		logger.info("Status Code ==> "+statusCode);
		Assert.assertEquals(statusCode, 200);
	}
	
	@Test
	void checkStatusLine() 
	{
		logger.info("********************* TC002 : M3 :CheckStatusLine *********************");
		String statusLine=response.getStatusLine();
		logger.info("Status Line ==> "+statusLine);
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK");
	}
	
	@Test
	void checkResponseTime() 
	{
		logger.info("********************* TC002 : M4: CheckResponseTime *********************");
		long responseTime=response.getTime();
		logger.info("Response Time ==> "+responseTime);
		
		if(responseTime>2000)
			logger.warn("Response Time is greater than 2000");
		Assert.assertTrue(responseTime<2000);
	}
	
	@Test
	void checkContentType() 
	{
		logger.info("********************* TC002 : M5: CheckContentType *********************");
		String contentType=response.header("Content-Type");
		logger.info("Content Type ==> "+contentType);
		Assert.assertEquals(contentType, "application/json");
	}
	
	@Test
	void checkServerType() 
	{
		logger.info("********************* TC002 : M6 :CheckServerType *********************");
		String serverType=response.header("Server");
		logger.info("Server Type ==> "+serverType);
		Assert.assertEquals(serverType, "cloudflare");
	}
	
	@Test
	void checkContentEncoding() 
	{
		logger.info("********************* TC002 : M7 :CheckContentEncoding *********************");
		String contentEncoding=response.header("Content-Encoding");
		logger.info("Content Encoding ==> "+contentEncoding);
		Assert.assertEquals(contentEncoding, "gzip");
	}
	
	@Test
	void checkContentLength() 
	{
		logger.info("********************* TC002 : M8 :CheckContentLength *********************");
		String contentLength=response.header("Content-Length");
		logger.info("Content Length ==> "+contentLength);
		
		if(Integer.parseInt(contentLength)<100)
			logger.warn("Content Length is less than 100");
		
		Assert.assertTrue(Integer.parseInt(contentLength)>100);
	}

	
	@AfterClass
	void tearDown()
	{
		logger.info("********************* Finished TC002_Get_Single_Employee_Record *********************");
	}

}
