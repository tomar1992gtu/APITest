package com.employeeapi.testCases;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC004_Get_With_MultipleParams {
	
	@Test
	void getWeatherRequest() {
		
		// Specify Base URI
		RestAssured.baseURI="https://samples.openweathermap.org/data/2.5/";
		
		// Create Request Object
		RequestSpecification httpRequest = RestAssured.given();
		
		// Create Response Object
		Response response = httpRequest.queryParam("q","London,UK")
                .queryParam("appid", "2b1fd2d7f77ccf1b7de9b441571b39b8").request(Method.GET,"/weather");
				
		// Body of Response		
		String responseBody = response.getBody().asString();
		System.out.println("Response Body : ");
		System.out.println(responseBody);
	}
}
